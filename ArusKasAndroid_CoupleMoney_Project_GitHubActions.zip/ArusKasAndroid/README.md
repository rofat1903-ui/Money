# Arus Kas Pribadi Android

Ini adalah **proyek Android Studio** yang membungkus file HTML Arus Kas Pribadi menjadi aplikasi Android menggunakan WebView.

## Isi proyek
- `app/src/main/assets/index.html` — aplikasi HTML utama.
- `MainActivity.java` — pembuka aplikasi HTML dalam WebView.
- `AndroidManifest.xml` — konfigurasi aplikasi.

## Cara membuat APK
1. Buka proyek ini di Android Studio.
2. Tunggu proses Gradle Sync selesai.
3. Pilih menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. File APK biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
- Proyek ini belum berupa APK jadi.
- Proses build memerlukan Android Studio, Android SDK, dan koneksi internet.
- Data aplikasi HTML menggunakan `localStorage` pada WebView perangkat.
