# Build APK melalui GitHub Actions (HP saja)

1. Buat repository GitHub baru.
2. Upload seluruh isi folder proyek ini, bukan file ZIP saja.
3. Pastikan folder `.github/workflows/build-apk.yml` ikut ter-upload.
4. Buka tab **Actions** pada repository.
5. Pilih workflow **Build Arus Kas APK**.
6. Tekan **Run workflow** jika tersedia, lalu jalankan.
7. Tunggu sampai status hijau/Success.
8. Buka hasil workflow dan bagian **Artifacts**.
9. Unduh `arus-kas-debug-apk.zip`, ekstrak, lalu instal `app-debug.apk` di HP.

Catatan: APK ini adalah debug APK untuk pengujian. Build belum dijamin berhasil sampai GitHub Actions menyelesaikannya.
